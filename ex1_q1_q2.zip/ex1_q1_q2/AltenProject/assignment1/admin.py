from django.contrib import admin

from .models import RouterDetails

admin.site.register(RouterDetails)
