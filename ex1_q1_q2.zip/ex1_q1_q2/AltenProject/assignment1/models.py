from django.db import models


class RouterDetails(models.Model):
    SapId = models.CharField(max_length=100)
    Hostname = models.CharField(max_length=100)
    Loopback = models.CharField(max_length=100)
    MacAddress = models.CharField(max_length=100)
