from django.apps import AppConfig


class Assignment1Config(AppConfig):
    name = 'assignment1'
